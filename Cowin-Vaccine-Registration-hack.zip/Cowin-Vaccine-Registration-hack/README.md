# CowinRegistration

Setup this Extension on chrome

Login

choose candidate

click schedule

You will go to appointment page.

Select Search By District / Search by Pin

Select State and District from dropdown for Search by District / Pin for Search by Pin

Don't click on Search

Go to Extension.

Select Age group you want to book for either 18+ / 45+

Select day you want to book for either Today / Tomorrow

click on Start Button From Extension

Now sit back and wait untill Extension find available slot for you.

onece it find available slot, you will be redirected to captcha page.

first time slot will auto select

just enter captcha and Book appointment.

Email navdep91289@gmail.com for any query.
